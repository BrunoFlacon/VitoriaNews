import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { cacheProfileImage } from "../_shared/media.ts";
import { resolveCorsOrigin } from "../_shared/cors.ts";

const corsHeaders = (req) => ({
  'Access-Control-Allow-Origin': resolveCorsOrigin(req),
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type, x-authorization",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
});


async function getCredentials(supabase: any, userId: string, platform: string): Promise<Record<string, any>> {
  try {
    const { data } = await supabase
      .from("api_credentials")
      .select("credentials")
      .eq("user_id", userId)
      .eq("platform", platform)
      .maybeSingle();
    return data?.credentials || {};
  } catch {
    return {};
  }
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders(req) });

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!
    );

    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Authorization required" }), {
        status: 401, headers: { ...corsHeaders(req), "Content-Type": "application/json" }
      });
    }

    const token = authHeader.replace("Bearer ", "");
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Invalid session" }), {
        status: 401, headers: { ...corsHeaders(req), "Content-Type": "application/json" }
      });
    }

    const userId = user.id;
    const creds = await getCredentials(supabase, userId, "google_cloud");
    const ytApiKey = creds?.youtube_api_key || creds?.apiKey;

    // Try to get OAuth token from YouTube connection
    const { data: ytConnection } = await supabase
      .from("social_connections")
      .select("access_token, platform_user_id")
      .eq("user_id", userId)
      .eq("platform", "youtube")
      .eq("is_connected", true)
      .maybeSingle();

    const ytAccessToken = ytConnection?.access_token;

    if (!ytAccessToken && !ytApiKey) {
      return new Response(JSON.stringify({ 
        success: true, 
        synced: 0, 
        reason: "YouTube OAuth connection or API key not configured" 
      }), {
        status: 200, headers: { ...corsHeaders(req), "Content-Type": "application/json" }
      });
    }

    const results: any[] = [];
    let totalViews = 0;
    let totalLikes = 0;
    let totalComments = 0;
    let totalSubscribersGained = 0;

    // Buscar subscriber count anterior para calcular ganho real
    let previousSubscribers = 0;
    try {
      const { data: prevAccount } = await supabase
        .from("social_accounts")
        .select("subscribers_count, followers_count, followers")
        .eq("user_id", userId)
        .eq("platform", "youtube")
        .maybeSingle();
      previousSubscribers = prevAccount?.subscribers_count || prevAccount?.followers_count || prevAccount?.followers || 0;
    } catch (_) { /* ok */ }

    // Step 1: Get channel ID
    let channelId = ytConnection?.platform_user_id;
    if (!channelId && ytAccessToken) {
      const channelsRes = await fetch(
        "https://www.googleapis.com/youtube/v3/channels?part=id&mine=true",
        { headers: { Authorization: `Bearer ${ytAccessToken}` } }
      );
      const channelsData = await channelsRes.json();
      if (channelsData.items?.[0]) {
        channelId = channelsData.items[0].id;
      }
    }

    if (!channelId) {
      return new Response(JSON.stringify({ 
        success: true, 
        synced: 0, 
        reason: "Could not determine YouTube channel ID" 
      }), {
        status: 200, headers: { ...corsHeaders(req), "Content-Type": "application/json" }
      });
    }

    // Step 2: Get channel statistics
    if (ytAccessToken) {
      const statsRes = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=statistics,snippet,brandingSettings&id=${channelId}`,
        { headers: { Authorization: `Bearer ${ytAccessToken}` } }
      );
      const statsData = await statsRes.json();
      const ch = statsData.items?.[0];
      if (ch) {
        const stats = ch.statistics || {};
        const snippet = ch.snippet || {};
        const branding = ch.brandingSettings?.image || {};

        const [cachedAvatar, cachedCover] = await Promise.all([
          cacheProfileImage(supabase, userId, "youtube", snippet.thumbnails?.high?.url, channelId),
          cacheProfileImage(supabase, userId, "youtube", branding.bannerExternalUrl, `${channelId}_cover`)
        ]);

        // Update social_accounts with latest data
        const currentSubscribers = parseInt(stats.subscriberCount || "0");
        totalSubscribersGained = Math.max(0, currentSubscribers - previousSubscribers);

        await supabase.from("social_accounts").upsert({
          user_id: userId,
          platform: "youtube",
          platform_user_id: channelId,
          username: snippet.customUrl || snippet.title || "",
          page_name: snippet.title || "",
          profile_picture: cachedAvatar || snippet.thumbnails?.high?.url || "",
          cover_photo: cachedCover || branding.bannerExternalUrl || "",
          followers_count: currentSubscribers,
          subscribers_count: currentSubscribers,
          posts_count: parseInt(stats.videoCount || "0"),
          views: parseInt(stats.viewCount || "0"),
          metadata: { posts_count: parseInt(stats.videoCount || "0") },
          is_connected: true,
          updated_at: new Date().toISOString(),
        }, { onConflict: "user_id,platform,platform_user_id" });

        // Also update social_connections with latest profile picture and stats
        const freshProfilePic = cachedAvatar || snippet.thumbnails?.high?.url || "";
        if (freshProfilePic) {
          await supabase.from("social_connections").update({
            profile_image_url: freshProfilePic,
            profile_picture: freshProfilePic,
            page_name: snippet.title || "",
            followers_count: currentSubscribers,
            posts_count: parseInt(stats.videoCount || "0"),
          }).eq("user_id", userId).eq("platform", "youtube").eq("platform_user_id", channelId);
        }

        results.push({
          type: "channel_stats",
          channel_id: channelId,
          title: snippet.title,
          subscribers: parseInt(stats.subscriberCount || "0"),
          videos: parseInt(stats.videoCount || "0"),
          views: parseInt(stats.viewCount || "0"),
          cover_photo: branding.bannerExternalUrl || ""
        });
      }
    }

    // Step 3: Get recent videos with detailed stats
    if (ytAccessToken) {
      const now = new Date();
      const fiveYearsAgo = new Date(now.getTime() - 5 * 365 * 24 * 60 * 60 * 1000);
      // YouTube API expects RFC 3339 formatted date-time values (e.g. 1970-01-01T00:00:00Z)
      const publishedAfter = fiveYearsAgo.toISOString().split('.')[0] + "Z";

      const searchRes = await fetch(
        `https://www.googleapis.com/youtube/v3/search?part=snippet&type=video&channelId=${channelId}&order=date&maxResults=50&publishedAfter=${publishedAfter}`,
        { headers: { Authorization: `Bearer ${ytAccessToken}` } }
      );
      const searchData = await searchRes.json();

      if (searchData.items?.length > 0) {
        const videoIds = searchData.items.map((v: any) => v.id.videoId).join(",");
        const videosRes = await fetch(
          `https://www.googleapis.com/youtube/v3/videos?part=statistics,snippet,contentDetails&id=${videoIds}`,
          { headers: { Authorization: `Bearer ${ytAccessToken}` } }
        );
        const videosData = await videosRes.json();

        let videoIdx = 0;
        for (const video of (videosData.items || [])) {
          const vStats = video.statistics || {};
          const vSnippet = video.snippet || {};
          const vDetails = video.contentDetails || {};

          const views = parseInt(vStats.viewCount || "0");
          const likes = parseInt(vStats.likeCount || "0");
          const comments = parseInt(vStats.commentCount || "0");
          const watchTimeMinutes = Math.round((parseInt(vStats.viewCount || "0") * 3) / 60); // estimate ~3min avg

          totalViews += views;
          totalLikes += likes;
          totalComments += comments;
          // Só o primeiro vídeo do lote carrega o ganho de inscritos (dado é canal, não vídeo)
          if (videoIdx === 0) {
            totalSubscribersGained = Math.max(0, totalSubscribersGained);
          }

          await supabase.from("youtube_analytics").upsert({
            user_id: userId,
            video_id: video.id,
            channel_id: channelId,
            title: vSnippet.title,
            views,
            watch_time_minutes: watchTimeMinutes,
            estimated_minutes_watched: watchTimeMinutes,
            likes,
            comments,
            subscribers_gained: videoIdx === 0 ? totalSubscribersGained : 0,
            date: vSnippet.publishedAt ? new Date(vSnippet.publishedAt).toISOString().split("T")[0] : null,
            metadata: {
              title: vSnippet.title,
              description: vSnippet.description?.substring(0, 200),
              thumbnail: vSnippet.thumbnails?.high?.url,
              duration: vDetails.duration,
              published_at: vSnippet.publishedAt,
              tags: vSnippet.tags || []
            },
            created_at: new Date().toISOString()
          });
          videoIdx++;

          results.push({
            type: "video",
            video_id: video.id,
            title: vSnippet.title,
            views,
            likes,
            comments,
            published_at: vSnippet.publishedAt
          });
        }
      }
    }

    // Step 4: If only API key (no OAuth), get public channel data
    if (ytApiKey && !ytAccessToken) {
      const res = await fetch(
        `https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&id=${channelId}&key=${ytApiKey}`
      );
      const data = await res.json();
      const ch = data.items?.[0];
      if (ch) {
        const stats = ch.statistics || {};
        const snippet = ch.snippet || {};
        const branding = ch.brandingSettings?.image || {};

        const [cachedAvatar, cachedCover] = await Promise.all([
          cacheProfileImage(supabase, userId, "youtube", snippet.thumbnails?.high?.url, channelId),
          cacheProfileImage(supabase, userId, "youtube", branding.bannerExternalUrl, `${channelId}_cover`)
        ]);

        await supabase.from("social_accounts").upsert({
          user_id: userId,
          platform: "youtube",
          platform_user_id: channelId,
          username: snippet.customUrl || snippet.title || "",
          page_name: snippet.title || "",
          profile_picture: cachedAvatar || snippet.thumbnails?.high?.url || "",
          cover_photo: cachedCover || branding.bannerExternalUrl || "",
          followers_count: parseInt(stats.subscriberCount || "0"),
          subscribers_count: parseInt(stats.subscriberCount || "0"),
          posts_count: parseInt(stats.videoCount || "0"),
          views: parseInt(stats.viewCount || "0"),
          metadata: { posts_count: parseInt(stats.videoCount || "0") },
          is_connected: true,
          updated_at: new Date().toISOString(),
        }, { onConflict: "user_id,platform,platform_user_id" });

        // Also update social_connections with latest profile picture and stats
        const freshProfilePic2 = cachedAvatar || snippet.thumbnails?.high?.url || "";
        if (freshProfilePic2) {
          await supabase.from("social_connections").update({
            profile_image_url: freshProfilePic2,
            profile_picture: freshProfilePic2,
            page_name: snippet.title || "",
            followers_count: parseInt(stats.subscriberCount || "0"),
            posts_count: parseInt(stats.videoCount || "0"),
          }).eq("user_id", userId).eq("platform", "youtube").eq("platform_user_id", channelId);
        }

        results.push({
          type: "channel_stats",
          channel_id: channelId,
          title: snippet.title,
          subscribers: parseInt(stats.subscriberCount || "0"),
          videos: parseInt(stats.videoCount || "0"),
          views: parseInt(stats.viewCount || "0"),
          cover_photo: branding.bannerExternalUrl || "",
          note: "Limited data - OAuth needed for video-level analytics"
        });
      }
    }

    // Get aggregated stats from youtube_analytics
    const { data: aggregatedData } = await supabase
      .from("youtube_analytics")
      .select("views, likes, comments, subscribers_gained")
      .eq("user_id", userId)
      .eq("channel_id", channelId);

    const aggregated = {
      total_views: totalViews,
      total_likes: totalLikes,
      total_comments: totalComments,
      total_subscribers_gained: totalSubscribersGained
    };

    if (aggregatedData?.length > 0) {
      aggregated.total_views = aggregatedData.reduce((s: number, r: any) => s + (r.views || 0), 0);
      aggregated.total_likes = aggregatedData.reduce((s: number, r: any) => s + (r.likes || 0), 0);
      aggregated.total_comments = aggregatedData.reduce((s: number, r: any) => s + (r.comments || 0), 0);
      aggregated.total_subscribers_gained = aggregatedData.reduce((s: number, r: any) => s + (r.subscribers_gained || 0), 0);
    }

    // Update social_accounts with aggregated metrics and engagement_rate
    const { data: ytAccount } = await supabase
      .from("social_accounts")
      .select("followers, followers_count, subscribers_count")
      .eq("user_id", userId)
      .eq("platform", "youtube")
      .eq("platform_user_id", channelId)
      .maybeSingle();

    const ytFollowers = ytAccount?.followers || ytAccount?.followers_count || ytAccount?.subscribers_count || 0;
    const ytEngagementRate = ytFollowers > 0
      ? parseFloat((((aggregated.total_likes + aggregated.total_comments) / ytFollowers) * 100).toFixed(2))
      : 0;

    // Only overwrite views/likes/comments if we have non-zero data
    // otherwise keep the existing lifetime values from the initial sync
    const updates: Record<string, any> = {
      user_id: userId,
      platform: "youtube",
      platform_user_id: channelId,
      engagement_rate: ytEngagementRate,
      last_synced_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
    };
    if (aggregated.total_views > 0) updates.views = aggregated.total_views;
    if (aggregated.total_likes > 0) updates.likes = aggregated.total_likes;
    if (aggregated.total_comments > 0) updates.comments = aggregated.total_comments;
    // Nota: subscribers_gained é armazenado em youtube_analytics, não em social_accounts

    await supabase.from("social_accounts").upsert(updates, { onConflict: "user_id,platform,platform_user_id" });

    return new Response(JSON.stringify({
      success: true,
      channel_id: channelId,
      synced: results.length,
      results,
      aggregated
    }), {
      headers: { ...corsHeaders(req), "Content-Type": "application/json" },
    });

  } catch (error: any) {
    return new Response(JSON.stringify({ error: error?.message || "Unknown error" }), {
      status: 500,
      headers: { ...corsHeaders(req), "Content-Type": "application/json" },
    });
  }
});

