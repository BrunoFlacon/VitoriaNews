// @ts-ignore
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
// @ts-ignore
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

declare const Deno: any;

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version, x-authorization, x-client-timestamp, x-user-id',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
};

const FETCH_TIMEOUT = 15000;
const FUNCTION_TIMEOUT = 35000;

function fetchWithTimeout(url: string, options: RequestInit = {}, ms = FETCH_TIMEOUT) {
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), ms);
  return fetch(url, { ...options, signal: controller.signal })
    .finally(() => clearTimeout(id));
}

async function getCredentials(supabase: any, userId: string, platform: string): Promise<Record<string, any>> {
  try {
    const { data } = await supabase
      .from("api_credentials")
      .select("credentials")
      .eq("user_id", userId)
      .eq("platform", platform)
      .maybeSingle();
    return data?.credentials || {};
  } catch {
    return {};
  }
}

async function processPlatform(conn: any, supabase: any) {
  try {
  let metrics: any = null;
  const recentPostsMetrics: any[] = [];

  // Skip if synced within last 5 minutes (avoids rapid re-syncs)
  // Exception: WhatsApp always syncs (profile photos may be missing)
  if (conn.updated_at && conn.platform !== "whatsapp") {
    const lastSync = new Date(conn.updated_at).getTime();
    if (Date.now() - lastSync < 300000) {
      console.log(`[${conn.platform}] ${conn.page_id || conn.platform_user_id}: skipped (synced ${Math.round((Date.now() - lastSync)/1000)}s ago)`);
      return;
    }
  }

  switch (conn.platform) {
    case "facebook": {
      if (!conn.access_token) break;
      const pageId = conn.page_id || conn.platform_user_id;

      // Count Facebook posts via /feed (includes shared + own content)
      let totalPostsCount: number | null = null;
      // Skip feed pagination if posts_count already exists from recent sync
      if (!conn.posts_count || conn.posts_count === 0) {
        try {
          let total = 0;
          let pages = 0;
          let url: string | null = `https://graph.facebook.com/v21.0/${pageId}/feed?fields=id&limit=100&access_token=${conn.access_token}`;
          while (url && pages < 50) {
            const r = await fetchWithTimeout(url);
            if (!r.ok) break;
            const d = await r.json();
            if (d.data) total += d.data.length;
            url = d.paging?.next || null;
            pages++;
          }
          totalPostsCount = total;
        } catch (e) {
          console.error("Error fetching Facebook posts count:", e);
        }
      }

      const finalPostsCount = totalPostsCount !== null ? totalPostsCount : (conn.posts_count || 0);

      // Simple fields — no insights (flaky permissions, timeout-prone)
      const fields = "followers_count,fan_count,picture.type(large),posts.limit(5){id,created_time,message}";
      const resp = await fetchWithTimeout(`https://graph.facebook.com/v21.0/${pageId}?fields=${fields}&access_token=${conn.access_token}`);

      if (resp.ok) {
        const data = await resp.json();
        const profilePic = data.picture?.data?.url || conn.profile_image_url || `https://graph.facebook.com/v21.0/${pageId}/picture?type=large`;

        metrics = {
          followers_count: typeof data.followers_count === "number" ? data.followers_count : (data.fan_count || 0),
          media_count: finalPostsCount,
          views_count: 0, // Requires page_insights permission; see Facebook Graph API /{page}/insights
          likes: typeof data.fan_count === "number" ? data.fan_count : 0,
          profile_picture: profilePic
        };

        // Collect post-level metrics from recent posts
        if (data.posts?.data) {
          for (const post of data.posts.data) {
            try {
              const insightResp = await fetchWithTimeout(
                `https://graph.facebook.com/v21.0/${post.id}/insights?metric=post_impressions,post_reactions_by_type_total&access_token=${conn.access_token}`
              );
              if (insightResp.ok) {
                const insightData = await insightResp.json();
                const impressions = insightData.data?.find((i: any) => i.name === 'post_impressions')?.values?.[0]?.value || 0;
                const reactionsData = insightData.data?.find((i: any) => i.name === 'post_reactions_by_type_total')?.values?.[0] || {};
                const totalReactions = Object.values(reactionsData).reduce((sum: number, val: any) => sum + (typeof val === 'number' ? val : 0), 0);

                recentPostsMetrics.push({
                  external_id: post.id,
                  platform: "facebook",
                  impressions,
                  likes: totalReactions,
                  comments: 0,
                  reach: impressions,
                  engagement: totalReactions,
                  content: post.message || null,
                  collected_at: new Date().toISOString()
                });
              }
            } catch (e) {
              // Silently skip post-level metrics — not critical
            }
          }
        }
      }
      break;
    }
    case "whatsapp": {
      if (!conn.access_token) break;
      let profilePic = "";
      let bizName = conn.page_name || "WhatsApp Business";
      let phoneId = conn.phone_number_id;

      // Clear page_id ONLY for 6 specific connections — preserve profile_image_url
      const BAD_CONN_NAMES = [
        "Central News", "Andje Wallace",
        "ADM - Marcha da Família", "ADM - IG. M Vida Eterna",
        "ADM - Tupã Pela Pátria", "ADM - Partido Liberal Tupã"
      ];
      let wasCleared = false;
      if (BAD_CONN_NAMES.some((n: string) => (conn.page_name || '').trim() === n)) {
        wasCleared = true;
        if (conn.page_id) {
          console.log(`[WA-SYNC] ${conn.page_name}: clearing page_id only (keeping profile_image_url for fallback)`);
          await supabase.from("social_connections").update({ page_id: null }).eq("id", conn.id);
          conn.page_id = null;
        }
      }
      (conn as any)._cleared = wasCleared;

      try {
        // If connection already has both phone_number_id AND profile_image_url (non-Facebook), skip resolution
        if (conn.phone_number_id && conn.profile_image_url && !conn.profile_image_url.includes('fbcdn')) {
          phoneId = conn.phone_number_id;
          profilePic = conn.profile_image_url;
          console.log(`[WA-SYNC] ${conn.page_name}: already has phone_number_id=${phoneId} + photo, skipping resolution`);
        } else {
        console.log(`[WA-SYNC] ${conn.page_name}: resolving phone_number_id (current=${phoneId || "null"})...`);
        let wabaIds: string[] = [];
        let fallbackPhoneId: string | null = null;
        let wabaToken = conn.access_token; // fallback to conn token (may be stale Page Token)

        let apiCredData: any = null;
        // First check api_credentials for stored WABA info and fresh access token
        try {
          const { data: apiCred } = await supabase
            .from("api_credentials")
            .select("credentials")
            .eq("user_id", conn.user_id)
            .eq("platform", "whatsapp")
            .maybeSingle();
          apiCredData = apiCred;
          if (apiCred?.credentials) {
            if (apiCred.credentials.waba_id) {
              console.log(`[WA-SYNC] ${conn.page_name}: found waba_id=${apiCred.credentials.waba_id} in api_credentials`);
              wabaIds.push(apiCred.credentials.waba_id);
            }
            if (apiCred.credentials.access_token) {
              wabaToken = apiCred.credentials.access_token;
              console.log(`[WA-SYNC] ${conn.page_name}: using fresh token from api_credentials`);
            }
            fallbackPhoneId = apiCred.credentials.phone_number_id || null;
          }
        } catch (e) {
          console.error(`[WA-SYNC] Failed to fetch api_credentials:`, e);
        }

        // After OAuth callback fix, api_credentials.waba_id IS the correct WABA ID.
        // Use it directly for phone_numbers calls. Fall back to conn.platform_user_id.
        wabaIds = wabaIds.length > 0 ? wabaIds : [conn.platform_user_id].filter(Boolean);

        // List phone numbers and match by name for EACH connection individually
        let matchedPhoneId: string | null = null;
        for (const wabaId of wabaIds) {
          try {
            const phoneListResp = await fetchWithTimeout(`https://graph.facebook.com/v21.0/${wabaId}/phone_numbers?access_token=${wabaToken}`);
            if (phoneListResp.ok) {
              const phoneListData = await phoneListResp.json();
              if (phoneListData.data && phoneListData.data.length > 0) {
                // Try name matching against this connection's page_name
                const connName = (conn.page_name || '').toLowerCase().trim();
                let bestPhone = null;
                let nameMatched = false;
                if (connName) {
                  for (const p of phoneListData.data) {
                    const pName = (p.verified_name || p.display_phone_number || '').toLowerCase().trim();
                    if (pName && (connName.includes(pName) || pName.includes(connName))) {
                      bestPhone = p;
                      nameMatched = true;
                      console.log(`[WA-SYNC] ${conn.page_name}: matched phone "${pName}" by name (id=${p.id})`);
                      break;
                    }
                  }
                }
                
                if (!nameMatched && phoneListData.data.length === 1) {
                  const isMain = connName.includes('banca') || connName.includes('paloma');
                  const phoneNameLower = (phoneListData.data[0].verified_name || '').toLowerCase();
                  const isPhoneMain = phoneNameLower.includes('banca') || phoneNameLower.includes('paloma');
                  if (isMain === isPhoneMain) {
                    bestPhone = phoneListData.data[0];
                    console.log(`[WA-SYNC] ${conn.page_name}: fallback to sole phone on compatible account (id=${bestPhone.id})`);
                  }
                }

                matchedPhoneId = bestPhone ? bestPhone.id : null;
                if (bestPhone) {
                  bizName = bestPhone.verified_name || bestPhone.display_phone_number || bizName;
                  console.log(`[WA-SYNC] ${conn.page_name}: resolved phone_number_id=${matchedPhoneId}, name="${bizName}" via WABA=${wabaId}`);
                }
                break;
              }
            } else {
              const errText = await phoneListResp.text().catch(() => "");
              console.warn(`[WA-SYNC] ${conn.page_name}: phone_numbers API status ${phoneListResp.status}: ${errText.substring(0,200)}`);
            }
          } catch (e) {
            console.error(`[WA-SYNC] ${conn.page_name}: phone list fetch error:`, String(e));
          }
        }

        // Use matched phoneId, or fallback to api_credentials phoneId, or keep existing
        if (matchedPhoneId) {
          phoneId = matchedPhoneId;
          await supabase.from("social_connections")
            .update({ phone_number_id: phoneId, page_name: bizName, waba_id: wabaIds[0] || null })
            .eq("id", conn.id);
          conn.phone_number_id = phoneId;
          conn.page_name = bizName;
        } else if (fallbackPhoneId && (!conn.waba_id || conn.waba_id === (apiCredData?.credentials?.waba_id || ''))) {
          // Only use fallback phone ID if this connection belongs to the main credentials account
          const isMainAccount = (conn.page_name || '').toLowerCase().trim().includes('banca') || 
                                (conn.page_name || '').toLowerCase().trim().includes('paloma');
          if (isMainAccount) {
            console.log(`[WA-SYNC] ${conn.page_name}: name matching failed, using fallback phone_number_id=${fallbackPhoneId} from api_credentials`);
            phoneId = fallbackPhoneId;
            await supabase.from("social_connections").update({ phone_number_id: phoneId, waba_id: wabaIds[0] || null }).eq("id", conn.id);
            conn.phone_number_id = phoneId;
          } else {
            console.log(`[WA-SYNC] ${conn.page_name}: skipping fallback phone ID to avoid photo/data cloning`);
          }
        } else if (phoneId) {
          console.log(`[WA-SYNC] ${conn.page_name}: keeping existing phone_number_id=${phoneId}`);
        } else {
          console.warn(`[WA-SYNC] ${conn.page_name}: could not resolve any phone_number_id`);
        }

        // Fetch WhatsApp profile photo
        // WhatsApp deve SEMPRE usar a foto do perfil oficial do WhatsApp (via WABA),
        // NÃO a foto da Página do Facebook. page_id pode apontar para a página errada
        // (ex: várias contas apontando para Ricardo Do Val), causando fotos clonadas.
        // Pular Priority 1 (Facebook Page /picture) e ir direto para foto WABA.
        // Priority 2: whatsapp_business_profile
        if (!profilePic && phoneId) {
          try {
            const bizUrl = `https://graph.facebook.com/v21.0/${phoneId}/whatsapp_business_profile?fields=profile_picture_url&access_token=${wabaToken}`;
            const bizResp = await fetchWithTimeout(bizUrl);
            if (bizResp.ok) {
              const bizData = await bizResp.json();
              profilePic = bizData.data?.[0]?.profile_picture_url || bizData.profile_picture_url || "";
              console.log(`[WA-PHOTO] ${conn.page_name}: P2 whatsapp_business_profile phoneId=${phoneId} pic=${profilePic ? 'YES' : 'NO'}`);
              if (profilePic) console.log(`[WA-PHOTO] ${conn.page_name}: P2 URL=${profilePic.substring(0,120)}...`);
            } else {
              const bizErr = await bizResp.text().catch(() => "");
              console.warn(`[WA-PHOTO] ${conn.page_name}: P2 failed status ${bizResp.status}: ${bizErr}`);
            }
          } catch (e) {
            console.error(`[WA-PHOTO] Error fetching whatsapp_business_profile:`, e);
          }
        }

        // Priority 3: WABA phone_numbers collection (the only reliable way to get profile_photo_url in v21.0)
        // profile_photo_url field DOES exist on the phone_numbers edge, but NOT on the individual phone node.
        // Must call on a WABA ID (not phone ID or Business Manager ID).
        if (!profilePic && wabaIds.length > 0) {
          for (const wid of wabaIds) {
            try {
              const phoneResp = await fetchWithTimeout(`https://graph.facebook.com/v21.0/${wid}/phone_numbers?fields=id,display_phone_number,profile_photo_url,verified_name&access_token=${wabaToken}`);
              if (phoneResp.ok) {
                const phoneData = await phoneResp.json();
                if (phoneData.error) {
                  console.warn(`[WA-PHOTO] ${conn.page_name}: P3 phone_numbers error via WABA ${wid}: ${phoneData.error.message}`);
                  continue;
                }
                if (phoneData.data && phoneData.data.length > 0) {
                  let phone = phoneData.data[0];
                  const connName = (conn.page_name || '').toLowerCase().trim();
                  if (connName && phoneData.data.length > 1) {
                    for (const p of phoneData.data) {
                      const pName = (p.verified_name || p.display_phone_number || '').toLowerCase().trim();
                      if (pName && (connName.includes(pName) || pName.includes(connName))) {
                        phone = p;
                        console.log(`[WA-PHOTO] ${conn.page_name}: P3 matched phone "${pName}" by name via WABA ${wid}`);
                        break;
                      }
                    }
                  }
                  profilePic = phone.profile_photo_url || "";
                  bizName = phone.verified_name || phone.display_phone_number || bizName;
                  if (!phoneId && phone.id) phoneId = phone.id;
                  console.log(`[WA-PHOTO] ${conn.page_name}: P3 phone_numbers WABA=${wid} pic=${profilePic ? 'YES' : 'NO'} (${phoneData.data.length} numbers)`);
                  if (profilePic) console.log(`[WA-PHOTO] ${conn.page_name}: P3 URL=${profilePic.substring(0,120)}...`);
                  if (!conn.phone_number_id && phone.id) {
                    await supabase.from("social_connections").update({ phone_number_id: phone.id, waba_id: wabaIds[0] || null }).eq("id", conn.id);
                    conn.phone_number_id = phone.id;
                    console.log(`[WA-PHOTO] ${conn.page_name}: saved phone_number_id=${phone.id}`);
                  }
                  if (profilePic) break; // found a photo, stop trying other WABAs
                }
              } else {
                const errText = await phoneResp.text().catch(() => "");
                console.warn(`[WA-PHOTO] ${conn.page_name}: P3 phone_numbers status ${phoneResp.status} via WABA ${wid}: ${errText.substring(0,200)}`);
              }
            } catch (e) {
              console.warn(`[WA-PHOTO] ${conn.page_name}: P3 error via WABA ${wid}:`, String(e));
            }
          }
        }

        // Priority 4 (last resort): Facebook Page /picture endpoint
        if (!profilePic) {
          const picCandidates = [
            conn.page_id ? `https://graph.facebook.com/v21.0/${conn.page_id}/picture?type=large` : null,
            conn.platform_user_id ? `https://graph.facebook.com/v21.0/${conn.platform_user_id}/picture?type=large` : null,
          ].filter(Boolean);
          for (const picUrl of picCandidates) {
            try {
              const picResp = await fetchWithTimeout(picUrl!);
              if (picResp.ok && picResp.headers.get("content-type")?.startsWith("image/")) {
                profilePic = picUrl!;
                console.log(`[WA-PHOTO] ${conn.page_name}: P4 Facebook picture FOUND`);
                break;
              } else {
                console.warn(`[WA-PHOTO] ${conn.page_name}: P4 failed for ${picUrl!.substring(0, 100)} (status ${picResp.status})`);
              }
            } catch (e) {
              console.warn(`[WA-PHOTO] ${conn.page_name}: P4 error:`, String(e));
            }
          }
        }
        } // end of else (skip resolution when already has phoneId + photo)
      } catch (e) {
        console.error("Error fetching WhatsApp details in collect-social-analytics:", e);
      }

      // Upload profile photo to Supabase Storage for permanent serving
      const origPic = profilePic;
      if (profilePic && profilePic.startsWith("http")) {
        // Retry with 1s delay on first failure
        for (let attempt = 0; attempt < 2; attempt++) {
          if (attempt > 0) await new Promise(r => setTimeout(r, 1000));
          try {
            const imgResp = await fetchWithTimeout(profilePic, {
              headers: {
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
                "Referer": "https://www.facebook.com/",
                "Accept": "image/avif,image/webp,image/apng,image/svg+xml,image/*,*/*;q=0.8",
              }
            });
            if (imgResp.ok) {
              const imgBlob = await imgResp.blob();
              const ct = imgResp.headers.get("content-type") || "image/png";
              const ext = ct.includes("png") ? "png" : ct.includes("webp") ? "webp" : "jpg";
              const fileName = `whatsapp/${conn.page_id || conn.platform_user_id || conn.id}.${ext}`;

              const { error: uploadError } = await supabase.storage
                .from("profile-photos")
                .upload(fileName, imgBlob, { contentType: ct, upsert: true });

              if (!uploadError) {
                const { data: pubUrl } = supabase.storage
                  .from("profile-photos")
                  .getPublicUrl(fileName);
                profilePic = pubUrl.publicUrl + `?v=${Date.now()}`;
                console.log(`[WA-PHOTO] ${conn.page_name}: uploaded to storage: ${profilePic}`);
                break;
              }
              console.error(`[WA-PHOTO] ${conn.page_name}: upload failed (attempt ${attempt + 1}):`, uploadError.message);
            } else {
              console.warn(`[WA-PHOTO] ${conn.page_name}: fetch status ${imgResp.status} (attempt ${attempt + 1})`);
            }
          } catch (e) {
            console.warn(`[WA-PHOTO] ${conn.page_name}: error attempt ${attempt + 1}:`, String(e));
          }
        }
      }
      // Never persist raw Meta CDN/Graph URL — fall back to last good cache
      if (profilePic && !profilePic.includes('supabase.co')) {
        profilePic = conn.profile_image_url || "";
        if (profilePic && profilePic.includes('supabase.co')) {
          console.log(`[WA-PHOTO] ${conn.page_name}: falling back to last cached image`);
        } else {
          profilePic = ""; // no cached version either
          console.log(`[WA-PHOTO] ${conn.page_name}: no cached image available`);
        }
      }
      // WhatsApp API doesn't expose per-phone-number followers/posts at account level.
      // Messages table stores ALL WhatsApp messages for a user (no connection_id column).
      // To avoid every connection showing the same total, we DIVIDE by the number
      // of active WhatsApp connections.
      let botSentCount = 0;
      let botAnsweredCount = 0;
      try {
        // Try per-connection filtering via metadata->>connection_id first (Fase 3)
        // Fall back to user-wide count ÷ connections for legacy messages
        const connFilter: any = conn.id ? { "metadata->>connection_id": conn.id } : {};
        const hasConnFilter = !!conn.id;

        async function countMsgs(filters: Record<string, any>): Promise<number> {
          let q = supabase.from("messages").select("*", { count: "exact", head: true });
          for (const [k, v] of Object.entries(filters)) q = q.eq(k, v);
          if (hasConnFilter) {
            // Prefer connection-tagged messages
            const { count: tagged } = await q.eq("metadata->>connection_id", conn.id) as any;
            if ((tagged || 0) > 0) return tagged;
          }
          const { count: total } = await q as any;
          return total || 0;
        }

        const totalSent = (await countMsgs({ user_id: conn.user_id, platform: "whatsapp", "metadata->>bot_reply": "true" }))
          || (await countMsgs({ user_id: conn.user_id, platform: "whatsapp", status: "sent" }));

        const receivedCount = await countMsgs({ user_id: conn.user_id, platform: "whatsapp", status: "received" });

        let totalAnswered = 0;
        if (receivedCount > 0) {
          totalAnswered = receivedCount;
        } else {
          const { data: botConvos } = await supabase
            .from("messages")
            .select("recipient_phone")
            .eq("user_id", conn.user_id)
            .eq("platform", "whatsapp")
            .eq("metadata->>bot_reply", "true")
            .not("recipient_phone", "is", null);
          const botPhones = new Set((botConvos || []).map((r: any) => r.recipient_phone));
          const { data: humanConvos } = await supabase
            .from("messages")
            .select("recipient_phone")
            .eq("user_id", conn.user_id)
            .eq("platform", "whatsapp")
            .or("metadata->>bot_reply.eq.false,metadata->>bot_reply.is.null")
            .not("recipient_phone", "is", null);
          const humanPhones = new Set((humanConvos || []).map((r: any) => r.recipient_phone));
          totalAnswered = [...botPhones].filter(p => humanPhones.has(p)).length;
        }

        // Divide total by number of active WhatsApp connections for per-connection stats (legacy fallback)
        let divisor = 1;
        if (!hasConnFilter || totalSent === 0) {
          const { count: waCount } = await supabase
            .from("social_connections")
            .select("*", { count: "exact", head: true })
            .eq("user_id", conn.user_id)
            .eq("platform", "whatsapp")
            .eq("is_connected", true);
          divisor = Math.max(waCount || 1, 1);
        }
        botSentCount = Math.round(totalSent / divisor);
        botAnsweredCount = Math.round(totalAnswered / divisor);
        console.log(`[WA-BOT-METRICS] ${conn.page_name}: total=${totalSent}, connections=${divisor}, per-conn=${botSentCount}`);
      } catch (e) {
        console.error("[WA-BOT-METRICS] DB query error:", e);
      }

      // Count unique contacts for this connection (item 1.3)
      let uniqueContacts = 0;
      try {
        let contactQuery = supabase
          .from("messages")
          .select("recipient_phone")
          .eq("user_id", conn.user_id)
          .eq("platform", "whatsapp")
          .not("recipient_phone", "is", null);
        if (conn.id) {
          contactQuery = contactQuery.eq("metadata->>connection_id", conn.id);
        }
        const { data: contactRows } = await contactQuery;
        if (contactRows) {
          uniqueContacts = new Set(contactRows.map((r: any) => r.recipient_phone)).size;
        }
      } catch (e) {
        console.warn("[WA-CONTACTS] Error counting unique contacts:", e);
      }

      metrics = {
        followers_count: 0,
        media_count: botSentCount,
        views_count: 0,
        profile_picture: profilePic,
        bot_posts_count: botSentCount,
        bot_answers_count: botAnsweredCount,
        unique_contacts_count: uniqueContacts,
      };
      break;
    }
    case "instagram": {
      if (!conn.access_token) break;
      const igUserId = conn.platform_user_id;
      // Removemos a query embutida de insights que falha ao misturar tipos de mídia (reels vs posts normais)
      const fields = "followers_count,media_count,name,username,profile_picture_url,media.limit(25){id,media_type,like_count,comments_count,caption,media_url,timestamp}";
      const resp = await fetchWithTimeout(`https://graph.facebook.com/v21.0/${igUserId}?fields=${fields}&access_token=${conn.access_token}`);
      if (resp.ok) {
        const data = await resp.json();
        // Get real Instagram profile views from insights
        let igViews = 0;
        try {
          const igViewsResp = await fetchWithTimeout(`https://graph.facebook.com/v21.0/${igUserId}/insights?metric=profile_views&period=day&access_token=${conn.access_token}`);
          if (igViewsResp.ok) {
            const igViewsData = await igViewsResp.json();
            if (igViewsData.data?.[0]?.values?.[0]?.value) {
              igViews = igViewsData.data[0].values[0].value;
            }
          }
        } catch (e) {
          console.warn("Could not fetch Instagram profile_views insights:", e);
        }
        metrics = {
          followers_count: data.followers_count || 0,
          media_count: data.media_count || 0,
          views_count: igViews,
          profile_picture: data.profile_picture_url || null
        };
        
        if (data.media?.data) {
          for (const media of data.media.data) {
            let impressions = 0;
            let reach = 0;
            let engagement = 0;
            let plays = 0;

            try {
              // Mapeia as métricas dependendo do tipo da mídia (VIDEO/REELS vs IMAGE/CAROUSEL_ALBUM)
              const metricsToFetch = media.media_type === "VIDEO" 
                ? "impressions,reach,plays,engagement" 
                : "impressions,reach,engagement";
                
              const insightResp = await fetchWithTimeout(
                `https://graph.facebook.com/v21.0/${media.id}/insights?metric=${metricsToFetch}&access_token=${conn.access_token}`
              );
              
              if (insightResp.ok) {
                const insightData = await insightResp.json();
                const insights = insightData.data || [];
                impressions = insights.find((i: any) => i.name === 'impressions')?.values?.[0]?.value || 0;
                reach = insights.find((i: any) => i.name === 'reach')?.values?.[0]?.value || 0;
                engagement = insights.find((i: any) => i.name === 'engagement')?.values?.[0]?.value || 0;
                if (media.media_type === "VIDEO") {
                  plays = insights.find((i: any) => i.name === 'plays')?.values?.[0]?.value || 0;
                }
              }
            } catch (e) {
              console.warn(`[IG] Failed to fetch insights for media ${media.id}:`, e);
            }

            recentPostsMetrics.push({
              external_id: media.id, 
              platform: "instagram",
              impressions,
              likes: media.like_count || 0, 
              comments: media.comments_count || 0,
              reach, 
              engagement, 
              plays,
              content: media.caption || null,
              media_url: media.media_url || null,
              collected_at: new Date().toISOString()
            });
          }
        }
      }
      break;
    }
    case "youtube": {
      if (!conn.access_token) break;
      const resp = await fetchWithTimeout(
        "https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&mine=true",
        { headers: { Authorization: `Bearer ${conn.access_token}` } }
      );
      if (resp.ok) {
        const data = await resp.json();
        const ch = data.items?.[0];
        if (ch) {
          metrics = {
            followers_count: parseInt(ch.statistics?.subscriberCount || "0"),
            media_count: parseInt(ch.statistics?.videoCount || "0"),
            views_count: parseInt(ch.statistics?.viewCount || "0"),
            profile_picture: ch.snippet?.thumbnails?.high?.url || ch.snippet?.thumbnails?.default?.url || null
          };
        }
      }
      break;
    }
    case "threads": {
      if (!conn.access_token) break;
      const thrUserId = conn.platform_user_id;
      if (thrUserId) {
        const resp = await fetchWithTimeout(
          `https://graph.threads.net/v1.0/me?fields=id,username,threads_profile_picture_url,followers_count&access_token=${conn.access_token}`
        );
        if (resp.ok) {
          const data = await resp.json();
          if (data && !data.error) {
            // Try to get media count from Threads
            let mediaCount = 0;
            try {
              const mediaResp = await fetchWithTimeout(
                `https://graph.threads.net/v1.0/${data.id}/threads?fields=id,text,like_count,reply_count,quote_count,repost_count&limit=50&access_token=${conn.access_token}`
              );
              const mediaData = await mediaResp.json();
              if (mediaData.data) {
                mediaCount = mediaData.data.length;
                
                for (const thread of mediaData.data) {
                  recentPostsMetrics.push({
                    external_id: thread.id,
                    platform: "threads",
                    impressions: 0,
                    likes: thread.like_count || 0,
                    comments: thread.reply_count || 0,
                    reach: 0,
                    engagement: (thread.like_count || 0) + (thread.reply_count || 0) + (thread.quote_count || 0) + (thread.repost_count || 0),
                    shares: thread.repost_count || 0,
                    content: thread.text || null,
                    collected_at: new Date().toISOString()
                  });
                }
                if (mediaData.paging?.next && mediaData.paging?.cursors?.after) {
                  let cursorAfter = mediaData.paging.cursors.after;
                  while (true) {
                    const nextRes = await fetchWithTimeout(
                      `https://graph.threads.net/v1.0/${data.id}/threads?fields=id,text,like_count,reply_count,quote_count,repost_count&limit=100&after=${cursorAfter}&access_token=${conn.access_token}`
                    );
                    const nextData = await nextRes.json();
                    if (!nextData.data || nextData.data.length === 0) break;
                    
                    for (const thread of nextData.data) {
                      recentPostsMetrics.push({
                        external_id: thread.id,
                        platform: "threads",
                        impressions: 0,
                        likes: thread.like_count || 0,
                        comments: thread.reply_count || 0,
                        reach: 0,
                        engagement: (thread.like_count || 0) + (thread.reply_count || 0) + (thread.quote_count || 0) + (thread.repost_count || 0),
                        shares: thread.repost_count || 0,
                        content: thread.text || null,
                        collected_at: new Date().toISOString()
                      });
                    }

                    mediaCount += nextData.data.length;
                    if (nextData.paging?.next && nextData.paging?.cursors?.after) {
                      cursorAfter = nextData.paging.cursors.after;
                    } else break;
                  }
                }
              }
            } catch (e) {
              console.warn("Could not fetch Threads media count:", e);
            }
            metrics = {
              followers_count: data.followers_count || 0,
              media_count: mediaCount,
              views_count: 0,
              profile_picture: data.threads_profile_picture_url || null
            };
          }
        }
      }
      break;
    }
    case "twitter": {
      if (conn.platform_user_id && conn.access_token) {
        const res = await fetchWithTimeout(
          `https://api.x.com/2/users/${conn.platform_user_id}?user.fields=profile_image_url,public_metrics`,
          { headers: { Authorization: `Bearer ${conn.access_token}` } }
        );
        if (res.ok) {
          const data = await res.json();
          if (data.data) {
            const m = data.data.public_metrics || {};
            metrics = {
              followers_count: m.followers_count || 0,
              media_count: m.tweet_count || 0,
              views_count: 0, // X API v2 does not expose aggregate tweet views at user level
              likes: m.like_count || 0,
              profile_picture: data.data.profile_image_url?.replace('_normal', '') || conn.profile_image_url || null,
            };
          }
        }

        // Collect post-level metrics from recent tweets (last 10)
        try {
          const tweetsRes = await fetchWithTimeout(
            `https://api.x.com/2/users/${conn.platform_user_id}/tweets?max_results=10&tweet.fields=public_metrics,created_at,text,attachments`,
            { headers: { Authorization: `Bearer ${conn.access_token}` } }
          );
          if (tweetsRes.ok) {
            const tweetsData = await tweetsRes.json();
            if (tweetsData.data) {
              for (const tweet of tweetsData.data) {
                const pm = tweet.public_metrics || {};
                recentPostsMetrics.push({
                  external_id: tweet.id,
                  platform: "twitter",
                  impressions: pm.impression_count || 0,
                  likes: pm.like_count || 0,
                  comments: pm.reply_count || 0,
                  reach: pm.impression_count || 0,
                  engagement: (pm.like_count || 0) + (pm.retweet_count || 0) + (pm.reply_count || 0) + (pm.quote_count || 0),
                  shares: (pm.retweet_count || 0) + (pm.quote_count || 0),
                  content: tweet.text || null,
                  collected_at: new Date().toISOString()
                });
              }
            }
          }
        } catch (e) {
          console.warn("Could not fetch Twitter post metrics:", e);
        }
      }
      break;
    }
    case "linkedin": {
      if (conn.access_token) {
        const resp = await fetchWithTimeout("https://api.linkedin.com/v2/userinfo", {
          headers: { Authorization: `Bearer ${conn.access_token}` }
        });
        if (resp.ok) {
          const data = await resp.json();
          metrics = {
            followers_count: conn.followers_count || 0,
            media_count: conn.posts_count || 0,
            views_count: 0,
            profile_picture: data.picture || null
          };
        }
        
        // Coletar posts e métricas (UGC Posts)
        const authorUrn = conn.platform_user_id || `urn:li:person:${data?.sub}`;
        try {
          const postsResp = await fetchWithTimeout(
            `https://api.linkedin.com/v2/ugcPosts?q=authors&authors=List(${encodeURIComponent(authorUrn)})&count=20`,
            { headers: { Authorization: `Bearer ${conn.access_token}`, "X-Restli-Protocol-Version": "2.0.0" } }
          );
          if (postsResp.ok) {
            const postsData = await postsResp.json();
            if (postsData.elements) {
              for (const post of postsData.elements) {
                // Para pegar views/likes precisamos da endpoint de socialActions (ou network shares)
                // Usando valores fallback (0) para métricas pois requer permissões específicas (rw_organization_admin ou similar)
                // A não ser que seja Organization, não temos acesso fácil aos likes do user sem query adicional.
                let contentText = null;
                try {
                   contentText = post.specificContent?.["com.linkedin.ugc.ShareContent"]?.shareCommentary?.text;
                } catch(e) {}
                
                recentPostsMetrics.push({
                  external_id: post.id,
                  platform: "linkedin",
                  impressions: 0,
                  likes: 0, // Fallback (API de Social Actions é restrita)
                  comments: 0,
                  reach: 0,
                  engagement: 0,
                  shares: 0,
                  content: contentText || null,
                  collected_at: new Date().toISOString()
                });
              }
            }
          }
        } catch (e) {
          console.warn("[LinkedIn] Error fetching ugcPosts metrics:", e);
        }
      }
      break;
    }
    case "tiktok": {
      if (conn.access_token) {
        const fields = "open_id,union_id,avatar_url,avatar_url_100,avatar_large_url,display_name,follower_count,following_count,likes_count,video_count";
        const resp = await fetchWithTimeout(`https://open.tiktokapis.com/v2/user/info/?fields=${fields}`, {
          headers: { Authorization: `Bearer ${conn.access_token}` }
        });
        if (resp.ok) {
          const data = await resp.json();
          const user = data?.data?.user;
          if (user) {
            metrics = {
              followers_count: user.follower_count || 0,
              media_count: user.video_count || 0,
              views_count: user.likes_count || 0,
              profile_picture: user.avatar_url_100 || user.avatar_url || user.avatar_large_url || null
            };
          }
        }
        
        // Coletar métricas dos vídeos recentes
        try {
          const videoResp = await fetchWithTimeout("https://open.tiktokapis.com/v2/video/list/?fields=id,title,video_description,like_count,comment_count,share_count,view_count", {
            method: "POST",
            headers: { 
              "Authorization": `Bearer ${conn.access_token}`,
              "Content-Type": "application/json"
            },
            body: JSON.stringify({ "max_count": 20 })
          });
          
          if (videoResp.ok) {
            const videoData = await videoResp.json();
            if (videoData.data?.videos) {
              for (const video of videoData.data.videos) {
                recentPostsMetrics.push({
                  external_id: video.id,
                  platform: "tiktok",
                  impressions: video.view_count || 0,
                  likes: video.like_count || 0,
                  comments: video.comment_count || 0,
                  reach: video.view_count || 0,
                  engagement: (video.like_count || 0) + (video.comment_count || 0) + (video.share_count || 0),
                  plays: video.view_count || 0,
                  shares: video.share_count || 0,
                  content: video.video_description || video.title || null,
                  collected_at: new Date().toISOString()
                });
              }
            }
          }
        } catch (e) {
          console.warn("[TikTok] Error fetching videos:", e);
        }
      }
      break;
    }
    case "pinterest": {
      if (conn.access_token) {
        metrics = {
          followers_count: conn.followers_count || 0,
          media_count: conn.posts_count || 0,
          views_count: 0,
          profile_picture: conn.profile_image_url || null
        };

        try {
          const pinsResp = await fetchWithTimeout("https://api.pinterest.com/v5/pins?page_size=25", {
            headers: { Authorization: `Bearer ${conn.access_token}` }
          });
          if (pinsResp.ok) {
            const pinsData = await pinsResp.json();
            if (pinsData.items) {
              for (const pin of pinsData.items) {
                // A API Analytics por Pin requer start_date e end_date. 
                // Por padrão, sem isso, cai no catch. Usaremos dados do próprio pin e 0 pros que precisam de chamadas adicionais pesadas.
                recentPostsMetrics.push({
                  external_id: pin.id,
                  platform: "pinterest",
                  impressions: 0,
                  likes: 0, // Pinterest usa saves/repins
                  comments: 0,
                  reach: 0,
                  engagement: 0,
                  shares: 0,
                  content: pin.description || pin.title || null,
                  media_url: pin.media?.images?.['1200x']?.url || null,
                  collected_at: new Date().toISOString()
                });
              }
            }
          }
        } catch (e) {
          console.warn("[Pinterest] Error fetching pins metrics:", e);
        }
      }
      break;
    }
    case "spotify": {
      if (conn.access_token) {
        const resp = await fetchWithTimeout("https://api.spotify.com/v1/me", { headers: { Authorization: `Bearer ${conn.access_token}` } });
        if (resp.ok) {
          const data = await resp.json();
          let albumCount = 0;
          let playlistCount = 0;
          try {
            const albumsResp = await fetchWithTimeout("https://api.spotify.com/v1/me/albums?limit=1", { headers: { Authorization: `Bearer ${conn.access_token}` } });
            if (albumsResp.ok) {
              const albumsData = await albumsResp.json();
              albumCount = albumsData.total || 0;
            }
          } catch (e) { /* ignore */ }
          try {
            const playlistsResp = await fetchWithTimeout("https://api.spotify.com/v1/me/playlists?limit=1", { headers: { Authorization: `Bearer ${conn.access_token}` } });
            if (playlistsResp.ok) {
              const playlistsData = await playlistsResp.json();
              playlistCount = playlistsData.total || 0;
            }
          } catch (e) { /* ignore */ }
          metrics = {
            followers_count: data.followers?.total || 0,
            media_count: albumCount + playlistCount,
            views_count: 0, // Spotify API does not expose stream/listen counts at profile level
            profile_picture: data.images?.[0]?.url || null
          };
        }
      } else {
        // No token — return zeros, not fabricated data
        metrics = { followers_count: 0, media_count: 0, views_count: 0 };
      }
      break;
    }
    case "googlenews": {
      const { data: artStats } = await supabase.from("articles").select("status").eq("user_id", conn.user_id);
      metrics = {
        followers_count: 0,
        media_count: artStats?.length || 0,
        views_count: (artStats?.filter(a => a.status === 'published').length || 0) * 150
      };
      break;
    }
    case "telegram": {
      try {
        const { count: channelCount } = await supabase
          .from("messaging_channels")
          .select("id", { count: "exact", head: true })
          .eq("user_id", conn.user_id);
        const { count: msgCount } = await supabase
          .from("messages")
          .select("id", { count: "exact", head: true })
          .eq("user_id", conn.user_id);
        metrics = {
          followers_count: channelCount || 0,
          media_count: msgCount || 0,
          views_count: 0, // Telegram Bot API does not expose profile/channel view counts
          profile_picture: conn.profile_image_url || null
        };
      } catch (e) {
        console.warn("Could not aggregate Telegram metrics:", e);
      }
      break;
    }
    case "kwai":
    case "rumble":
    case "gettr":
    case "truthsocial": {
      // No public API available — return zeros (no fabricated data)
      metrics = {
        followers_count: 0,
        media_count: 0,
        views_count: 0,
      };
      break;
    }
  }

  if (metrics) {
    if (!conn.is_virtual) {
      // All platforms fall back to existing profile_image_url (set by OAuth callback or storage recovery)
      const finalPic = metrics.profile_picture || conn.profile_image_url || "";
      console.log(`[SAVE] ${conn.platform}/${conn.page_name}: finalPic=${finalPic ? 'YES' : 'NO'}, followers=${metrics.followers_count}, posts=${metrics.media_count}`);
      await supabase.from("social_connections").update({
        profile_image_url: finalPic,
        profile_picture: finalPic,
        followers_count: typeof metrics.followers_count === "number" ? metrics.followers_count : conn.followers_count,
        posts_count: typeof metrics.media_count === "number" ? metrics.media_count : conn.posts_count
      }).eq("id", conn.id);
      conn.profile_image_url = finalPic;
    }

    const finalFollowers = typeof metrics.followers_count === "number" ? metrics.followers_count : 0;
    const finalPosts = typeof metrics.media_count === "number" ? metrics.media_count : 0;
    const finalLikes = typeof metrics.likes === "number" ? metrics.likes : 0;
    const finalShares = typeof metrics.shares === "number" ? metrics.shares : 0;
    const finalComments = typeof metrics.comments === "number" ? metrics.comments : 0;

    // CRITICAL: For WhatsApp, NEVER use conn.page_id as the platform_user_id.
    // conn.page_id holds the linked Facebook page ID (e.g. 323348644425052), NOT the WA phone ID.
    // Using page_id here creates duplicate social_accounts entries with FB IDs for WA platform.
    const puid = conn.platform === 'whatsapp'
      ? (conn.platform_user_id || `manual_whatsapp_${Date.now()}`)
      : (conn.page_id || conn.platform_user_id || `manual_${conn.platform}_${Date.now()}`);
    const { data: account } = await supabase.from("social_accounts").upsert({
      user_id: conn.user_id,
      platform: conn.platform,
      platform_user_id: puid,
      username: conn.page_name || conn.username || "",
      profile_picture: metrics.profile_picture || conn.profile_image_url || "",
      followers_count: finalFollowers,
      total_followers: finalFollowers,
      posts_count: finalPosts,
      total_posts: finalPosts,
      views: metrics.views_count || 0,
      likes: finalLikes,
      shares: finalShares,
      comments: finalComments,
      metadata: {
        posts_count: finalPosts,
        is_virtual: conn.is_virtual,
        ...(conn.platform === "whatsapp" ? {
          bot_posts_count: metrics.bot_posts_count ?? 0,
          bot_answers_count: metrics.bot_answers_count ?? 0,
        } : {}),
      },
      is_connected: true,
      updated_at: new Date().toISOString(),
    }, { onConflict: "user_id,platform,platform_user_id" }).select("id").maybeSingle();

    if (account) {
      await supabase.from("account_metrics").insert({
        user_id: conn.user_id,
        social_account_id: account.id,
        platform: conn.platform,
        followers: finalFollowers,
        likes: finalLikes,
        shares: finalShares,
        comments: finalComments,
        posts_count: finalPosts,
        views: metrics.views_count || 0,
        reach: metrics.reach || 0,
        profile_visits: metrics.profile_visits || 0,
        new_followers: metrics.new_followers || 0,
        engagement_rate: typeof metrics.engagement_rate === 'number' ? metrics.engagement_rate : null,
        messages_sent_count: metrics.bot_posts_count || metrics.media_count || 0,
        messages_delivered_count: metrics.reach || 0,
        unique_contacts_count: metrics.unique_contacts_count || 0,
        collected_at: new Date().toISOString()
      });

      // For WhatsApp, also populate messaging_channels
      if (conn.platform === 'whatsapp' && conn.phone_number_id) {
        const phoneId = conn.phone_number_id;
        const finalPic = metrics.profile_picture || conn.profile_image_url || "";
        const { data: existingChannel } = await supabase
          .from("messaging_channels")
          .select("id")
          .eq("user_id", conn.user_id)
          .eq("platform", "whatsapp")
          .eq("channel_id", phoneId)
          .maybeSingle();
        const channelPayload = {
          user_id: conn.user_id,
          platform: "whatsapp",
          channel_id: phoneId,
          channel_name: conn.page_name || "WhatsApp",
          profile_picture: finalPic,
          members_count: finalFollowers,
          online_count: 0,
          updated_at: new Date().toISOString(),
        };
        if (existingChannel) {
          await supabase.from("messaging_channels").update(channelPayload).eq("id", existingChannel.id);
        } else {
          await supabase.from("messaging_channels").insert(channelPayload);
        }
        console.log(`[WA-CHANNEL] ${conn.page_name}: messaging_channel upserted for phone ${phoneId}`);
      }

      if (recentPostsMetrics.length > 0) {
        for (const postMetric of recentPostsMetrics) {
          await supabase.from("post_metrics").upsert({
            ...postMetric,
            social_account_id: account.id,
            user_id: conn.user_id
          }, { onConflict: "external_id,platform" });
        }
      }
    }
  }

  return { platform: conn.platform, status: metrics ? "ok" : "skipped", virtual: !!conn.is_virtual, cleared: !!(conn as any)._cleared };
  } catch (err) {
    console.error(`[collect-social-analytics] processPlatform error for ${conn.platform}/${conn.page_name || conn.platform_user_id}:`, String(err));
    return { platform: conn.platform, status: "error", error: String(err), virtual: !!conn.is_virtual, cleared: false };
  }
}

serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const timeoutId = setTimeout(() => {
    console.error("[collect-social-analytics] Function timeout reached, returning partial results");
  }, FUNCTION_TIMEOUT);

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || Deno.env.get("SUPABASE_ANON_KEY") || "";
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get("Authorization") || "";
    const apikey = req.headers.get("apikey") || "";
    const xUserId = req.headers.get("x-user-id") || "";

    let userId = xUserId || "";

    if (authHeader && authHeader.startsWith("Bearer ")) {
      const authClient = createClient(supabaseUrl, Deno.env.get("SUPABASE_ANON_KEY")!, {
        global: { headers: { Authorization: authHeader } }
      });
      const { data: { user }, error } = await authClient.auth.getUser();
      if (!error && user) {
        userId = user.id;
      }
    }

    let reqBody: any = {};
    try {
      reqBody = await req.json().catch(() => ({}));
    } catch {}

    // Fallback: body.userId
    if (!userId && reqBody.userId) {
      userId = reqBody.userId;
    }

    // Fallback: allow anon key + x-user-id for internal calls
    const isSystemAccess = apikey && (
      apikey === Deno.env.get("SUPABASE_ANON_KEY") ||
      apikey === Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")
    );

    if (!userId && !isSystemAccess) {
      clearTimeout(timeoutId);
      return new Response(JSON.stringify({ 
        success: false, 
        message: "No accounts to collect - auth required" 
      }), {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" }
      });
    }

    if (!userId && isSystemAccess && xUserId) {
      userId = xUserId;
    }

    if (!userId) {
      clearTimeout(timeoutId);
      return new Response(JSON.stringify({ 
        success: true, 
        message: "No user context available" 
      }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // DEDUPLICATE: Merge WhatsApp connections with the same page_name
    // (caused by OAuth callback creating entries with different platform_user_ids).
    // Keeps the connection with most data (phone_number_id + profile_image_url),
    // deactivates extras, and copies data from keeper to the surviving connection.
    try {
      const { data: allWa } = await supabase
        .from("social_connections")
        .select("id,page_name,page_id,phone_number_id,profile_image_url,waba_id,is_connected,is_primary")
        .eq("platform", "whatsapp");
      const byName: Record<string, any[]> = {};
      for (const c of (allWa || [])) {
        const key = (c.page_name || '').trim().toLowerCase();
        if (!byName[key]) byName[key] = [];
        byName[key].push(c);
      }
      let dedupCount = 0;
      for (const [name, group] of Object.entries(byName)) {
        if (group.length <= 1) continue;
        // Sort: most complete data first (has phone_number_id + photo > has photo > has neither),
        // but ALWAYS keep is_primary at the top (never deactivate the default profile)
        group.sort((a, b) => {
          if (a.is_primary && !b.is_primary) return -1;
          if (!a.is_primary && b.is_primary) return 1;
          const scoreA = (a.phone_number_id ? 1 : 0) + (a.profile_image_url ? 1 : 0);
          const scoreB = (b.phone_number_id ? 1 : 0) + (b.profile_image_url ? 1 : 0);
          return scoreB - scoreA;
        });
        const keeper = group[0];
        const duplicates = group.slice(1).filter(d => d.is_connected);
        if (duplicates.length === 0) continue;
        // Keep the one with best data. If keeper is primary, keep primary + copy extra data to it.
        // If keeper is not primary but a duplicate IS, keep the primary and copy keeper data to it.
        let survivor = keeper;
        let toDeactivate = duplicates.map(d => d.id);
        const primaryDup = duplicates.find(d => d.is_primary);
        if (primaryDup) {
          survivor = primaryDup;
          toDeactivate = [keeper.id, ...duplicates.filter(d => d.id !== primaryDup.id).map(d => d.id)];
        }
        const updateData: any = { updated_at: new Date().toISOString() };
        if (keeper.profile_image_url && !(survivor.profile_image_url)) updateData.profile_image_url = keeper.profile_image_url;
        if (keeper.phone_number_id && !(survivor.phone_number_id)) updateData.phone_number_id = keeper.phone_number_id;
        if (keeper.waba_id && !(survivor.waba_id)) updateData.waba_id = keeper.waba_id;
        if (Object.keys(updateData).length > 1) {
          await supabase.from("social_connections").update(updateData).eq("id", survivor.id);
        }
        for (const dupId of toDeactivate) {
          await supabase.from("social_connections").update({ is_connected: false, updated_at: new Date().toISOString() }).eq("id", dupId);
        }
        dedupCount += toDeactivate.length;
        console.log(`[DEDUP] ${name}: kept=${survivor.id}, deactivated=${toDeactivate.length} duplicates`);
      }
      if (dedupCount > 0) console.log(`[DEDUP] Merged ${dedupCount} duplicate connections`);
    } catch (e) {
      console.error(`[DEDUP] Failed:`, String(e));
    }

    const { data: connections } = await supabase
      .from("social_connections")
      .select("*")
      .eq("user_id", userId)
      .eq("is_connected", true);

    // Copy profile_image_url from api_credentials to WhatsApp connections that lack one
    // (OAuth callback now stores it there with correct WABA ID resolution)
    if (connections) {
      try {
        const { data: waCred } = await supabase
          .from("api_credentials")
          .select("credentials")
          .eq("platform", "whatsapp")
          .eq("user_id", userId)
          .maybeSingle();
        if (waCred?.credentials?.profile_image_url) {
          const photoUrl = waCred.credentials.profile_image_url;
          const waConns = connections.filter((c: any) => c.platform === "whatsapp" && !c.profile_image_url);
          if (waConns.length > 0) {
            const ids = waConns.map((c: any) => c.id);
            await supabase.from("social_connections").update({ profile_image_url: photoUrl }).in("id", ids);
            console.log(`[WA-SYNC] Copied profile_image_url from api_credentials to ${waConns.length} WhatsApp connections`);
            for (const c of waConns) c.profile_image_url = photoUrl;
          }
        }
      } catch (e) {
        console.error("[WA-SYNC] Failed to copy photo from api_credentials:", e);
      }
    }

    const { data: manualCreds } = await supabase
      .from("api_credentials")
      .select("*");

    const processingQueue: any[] = [...(connections || [])];
    const manualOnlyPlatforms = ["kwai", "rumble", "gettr", "truthsocial", "spotify", "googlenews"];

    if (manualCreds) {
      for (const cred of manualCreds) {
        if (manualOnlyPlatforms.includes(cred.platform)) {
          const exists = processingQueue.some(c => c.platform === cred.platform && c.user_id === cred.user_id);
          if (!exists) {
            processingQueue.push({
              user_id: cred.user_id,
              platform: cred.platform,
              is_connected: true,
              platform_user_id: cred.credentials?.username || `user_${cred.platform}`,
              page_name: cred.credentials?.username || cred.platform,
              is_virtual: true
            });
          }
        }
      }
    }

    let filteredQueue = [...processingQueue];
    if (reqBody.platform) {
      filteredQueue = filteredQueue.filter(c => c.platform === reqBody.platform);
    }

    if (filteredQueue.length === 0) {
      clearTimeout(timeoutId);
      // Diagnostics before state change
      const waConns = (connections || []).filter((c: any) => c.platform === 'whatsapp');
      const waDiag = waConns.map((c: any) => ({
        name: c.page_name,
        page_id: c.page_id,
        platform_user_id: c.platform_user_id,
        phone_number_id: c.phone_number_id,
        has_page_id: !!c.page_id,
      }));
      return new Response(JSON.stringify({ success: true, message: "No accounts to collect", diagnostics: { wa: waDiag } }), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const results = await Promise.all(
      filteredQueue.map(conn => processPlatform(conn, supabase))
    );

    clearTimeout(timeoutId);
    // Diagnostics after processing — fresh DB query for accurate state
    const { data: finalConns } = await supabase
      .from("social_connections")
      .select("page_name,page_id,platform_user_id,phone_number_id,profile_image_url")
      .eq("user_id", userId)
      .eq("platform", "whatsapp")
      .eq("is_connected", true);
    const waDiag = (finalConns || []).map((c: any) => ({
      name: c.page_name,
      page_id: c.page_id,
      platform_user_id: c.platform_user_id,
      phone_number_id: c.phone_number_id,
      has_page_id: !!c.page_id,
      profile_image_url: c.profile_image_url || null,
    }));
    return new Response(JSON.stringify({ success: true, results, diagnostics: { wa: waDiag }, _v: "v5-preserve" }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    clearTimeout(timeoutId);
    return new Response(JSON.stringify({ error: String(error) }), {
      status: 500,
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
